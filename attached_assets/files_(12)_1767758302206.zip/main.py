import os
import asyncio
import random
import time
from datetime import datetime, timedelta
from collections import defaultdict
import aiohttp
from telegram import Update, ChatPermissions
from telegram.ext import Application, CommandHandler, MessageHandler, ChatMemberHandler, ContextTypes, filters
from telegram.constants import ParseMode

# Environment variables
TELEGRAM_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN')
GROK_API_KEY = os.environ.get('GROK_API_KEY', '')
BANANAGUN_API_KEY = os.environ.get('BANANAGUN_API_KEY', '')

# Bot state tracking
user_behavior = defaultdict(lambda: {'warnings': 0, 'last_warning': None, 'mode': 'friendly'})
last_activity_time = time.time()
used_jokes = set()
admin_ids = set()

# Dudley Bud Characters
DUDLEY_CHARACTERS = [
    "Dudley Bud - The main character, a chill cannabis bud",
    "Blaze - Dudley's adventurous friend",
    "Kush - The wise elder bud",
    "Sativa - The energetic uplifting character",
    "Indica - The relaxed, mellow character"
]

# Cannabis jokes and dad jokes
JOKES = [
    "Why did the cannabis plant go to school? To get a little higher education! 🌿📚",
    "What's a stoner's favorite type of music? Rock... and roll! 🎸",
    "Why don't cannabis plants ever get lost? They always follow the high way! 🛣️",
    "What did the cannabis say to the paper? Let's roll! 📜",
    "Why was the cannabis plant so good at meditation? It knew how to find inner peace! 🧘",
    "What do you call a cannabis plant that tells jokes? A pun-t! 😄",
    "Why did Dudley Bud become a comedian? He wanted to get everyone's spirits lifted! 🎭",
    "What's Dudley's favorite subject? Higher mathematics! ➕",
    "Why don't cannabis plants use social media? They prefer to stay grounded! 🌱",
    "What did one bud say to another? We make a great joint effort! 🤝"
]

MEDICAL_FACTS = [
    "🏥 Medical cannabis has been shown to help with chronic pain management in numerous clinical studies.",
    "🧠 CBD (cannabidiol) is non-psychoactive and has been researched for anxiety and seizure disorders.",
    "💊 Cannabis contains over 100 cannabinoids, each with potentially different therapeutic properties.",
    "🌿 Medical cannabis is legal in 38+ US states and many countries worldwide for various conditions.",
    "📊 Studies show cannabis can help with nausea, especially in chemotherapy patients.",
    "🔬 The endocannabinoid system in our bodies naturally interacts with cannabis compounds.",
    "⚕️ Always consult healthcare professionals before using cannabis for medical purposes."
]

# Scam detection patterns
SCAM_INDICATORS = {
    'crypto_address': ['0x', 'bc1', 'eth:', 'btc:'],
    'marketing_terms': ['marketing', 'promotion', 'advertising', 'sponsor', 'partnership'],
    'suspicious_words': ['investment', 'profit', 'guaranteed', 'double your', 'airdrop'],
    'porn_related': ['xxx', 'porn', 'nsfw', 'onlyfans', 'sex']
}

# Dudley Bud Project Info
PROJECT_INFO = """
🌿 **Dudley Bud - Web3 Cannabis Character Universe**

Built on Base blockchain, Dudley Bud is a creative storytelling project featuring:

📦 **Collections:**
- Limited Whitelist NFTs (priority access)
- Dudley420 Collection: 1,000 NFTs @ 0.01 BASE

🎭 **What We Are:**
✅ Creative Web3 storytelling
✅ Digital art & character universe
✅ Community-driven entertainment
✅ Animation, games & experiences

❌ **What We're NOT:**
❌ Investment opportunity
❌ Financial product
❌ Promise of profit

🎁 **Community Gifts:**
Up to 25% of profits may be allocated to discretionary community gifts - but these are NOT guaranteed, automatic, or proportional.

🌐 **Links:**
Website: dudleybud.com
X: x.com/dudley420
Telegram: t.me/dudley420

⚠️ **Important:** NFTs are for entertainment and collecting only. No financial returns promised!
"""

class DudleyBot:
    def __init__(self):
        self.session = None
        
    async def call_grok(self, prompt, system_message="You are Dudley Bud's AI assistant - friendly, knowledgeable about cannabis culture, and protective of the community."):
        """Call Grok AI for responses"""
        if not GROK_API_KEY:
            return "Grok AI not configured yet - but Dudley says hi! 🌿"
            
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
                
            headers = {
                "Authorization": f"Bearer {GROK_API_KEY}",
                "Content-Type": "application/json"
            }
            
            data = {
                "model": "grok-beta",
                "messages": [
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.8
            }
            
            async with self.session.post(
                "https://api.x.ai/v1/chat/completions",
                headers=headers,
                json=data,
                timeout=30
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    return result['choices'][0]['message']['content']
                else:
                    return "Hmm, Dudley's having trouble thinking right now... 🤔"
                    
        except Exception as e:
            print(f"Grok API error: {e}")
            return "Dudley's taking a quick break! Try again in a moment. 😊"
    
    async def generate_image(self, prompt):
        """Generate image with BananaGun (20% chance)"""
        if random.random() > 0.2:  # 80% chance to skip
            return None
            
        if not BANANAGUN_API_KEY:
            return None
            
        try:
            # BananaGun API integration would go here
            # For now, returning None as placeholder
            return None
        except Exception as e:
            print(f"Image generation error: {e}")
            return None
    
    async def detect_scammer(self, user, username, first_name):
        """Check for scam indicators"""
        flags = []
        name_check = (username or '') + (first_name or '')
        name_lower = name_check.lower()
        
        # Check for crypto addresses
        for indicator in SCAM_INDICATORS['crypto_address']:
            if indicator in name_lower:
                flags.append("crypto_address_in_name")
        
        # Check for marketing terms
        for term in SCAM_INDICATORS['marketing_terms']:
            if term in name_lower:
                flags.append("marketing_term")
        
        # Check for porn-related terms
        for term in SCAM_INDICATORS['porn_related']:
            if term in name_lower:
                flags.append("porn_in_username")
        
        return flags
    
    async def get_crypto_prices(self):
        """Fetch crypto market data"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            # CoinGecko free API
            async with self.session.get(
                "https://api.coingecko.com/api/v3/simple/price?ids=ethereum,base&vs_currencies=usd&include_24hr_change=true",
                timeout=10
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    return data
        except Exception as e:
            print(f"Crypto price error: {e}")
        return None

bot = DudleyBot()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle /start command"""
    await update.message.reply_text(
        "🌿 Hey there! I'm the Dudley Bud Guardian Bot!\n\n"
        "I'm here to help, entertain, and protect our community.\n\n"
        "Commands:\n"
        "/about - Learn about Dudley Bud\n"
        "/prices - Check crypto prices\n"
        "/joke - Get a random joke\n"
        "/fact - Cannabis medical fact\n"
        "/safety - Security reminders\n\n"
        "Just chat with me naturally and I'll help out! 😊"
    )

async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Explain Dudley Bud project"""
    await update.message.reply_text(PROJECT_INFO, parse_mode=ParseMode.MARKDOWN)

async def prices_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show crypto prices"""
    prices = await bot.get_crypto_prices()
    if prices:
        eth = prices.get('ethereum', {})
        base = prices.get('base', {})
        
        message = "💰 **Crypto Market Update**\n\n"
        if eth:
            change = eth.get('usd_24h_change', 0)
            emoji = "📈" if change > 0 else "📉"
            message += f"ETH: ${eth.get('usd', 0):,.2f} {emoji} {change:+.2f}%\n"
        if base:
            change = base.get('usd_24h_change', 0)
            emoji = "📈" if change > 0 else "📉"
            message += f"BASE: ${base.get('usd', 0):,.6f} {emoji} {change:+.2f}%\n"
        
        await update.message.reply_text(message, parse_mode=ParseMode.MARKDOWN)
    else:
        await update.message.reply_text("Can't fetch prices right now, but HODL strong! 💎🙌")

async def joke_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Tell a random joke"""
    available_jokes = [j for j in JOKES if j not in used_jokes]
    if not available_jokes:
        used_jokes.clear()
        available_jokes = JOKES
    
    joke = random.choice(available_jokes)
    used_jokes.add(joke)
    await update.message.reply_text(joke)

async def fact_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share medical cannabis fact"""
    fact = random.choice(MEDICAL_FACTS)
    await update.message.reply_text(fact)

async def safety_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Share safety reminders"""
    safety_msg = (
        "🛡️ **Dudley Bud Safety Reminders**\n\n"
        "1. 📌 Always read pinned messages\n"
        "2. 🚫 Team NEVER DMs first\n"
        "3. 🔗 NEVER click links unless approved & pinned by team\n"
        "4. 👥 Watch for crypto addresses in usernames\n"
        "5. 🎭 Beware of marketing DMs\n"
        "6. 📞 Voice verify any 'proposals'\n\n"
        "Stay safe, Dudley fam! 🌿✨"
    )
    await update.message.reply_text(safety_msg, parse_mode=ParseMode.MARKDOWN)

async def welcome_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Welcome new members and check for scammers"""
    for member in update.chat_member.new_chat_members or []:
        user = member.from_user
        
        # Check for scam indicators
        scam_flags = await bot.detect_scammer(
            user,
            user.username,
            user.first_name
        )
        
        if scam_flags:
            warning = f"⚠️ Warning: New member @{user.username or user.first_name} has suspicious indicators: {', '.join(scam_flags)}\n\n"
            warning += "Admins, please verify! 👀"
            await update.effective_chat.send_message(warning)
            return
        
        # Normal welcome
        welcome = (
            f"🌿 Welcome to Dudley Bud, {user.first_name}! 👋\n\n"
            f"Great to have you here! Before we get started:\n\n"
            f"📌 Please read the **pinned messages**\n"
            f"🚫 Our team **NEVER DMs first**\n"
            f"🔗 **NEVER click links** unless approved by admins\n\n"
            f"Got questions? Just ask! We're here to help! 😊🌿"
        )
        await update.effective_chat.send_message(welcome)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle all messages with AI and behavior tracking"""
    global last_activity_time
    
    if not update.message or not update.message.text:
        return
    
    last_activity_time = time.time()
    user_id = update.effective_user.id
    username = update.effective_user.username or update.effective_user.first_name
    message_text = update.message.text.lower()
    
    # Check if user is admin
    chat_member = await context.bot.get_chat_member(update.effective_chat.id, user_id)
    is_admin = chat_member.status in ['creator', 'administrator']
    
    if is_admin:
        admin_ids.add(user_id)
    
    # Check for rude behavior
    rude_words = ['fuck you', 'stfu', 'shut up', 'idiot', 'stupid bot', 'dumb']
    is_rude = any(word in message_text for word in rude_words)
    
    if is_rude and not is_admin:
        user_behavior[user_id]['warnings'] += 1
        warnings = user_behavior[user_id]['warnings']
        
        if warnings == 1:
            # First warning - go Karen mode
            user_behavior[user_id]['mode'] = 'karen'
            response = await bot.call_grok(
                f"The user '{username}' was rude to you. Respond in a 'Karen' mode - entitled, demanding, but still somewhat professional. Their message: {update.message.text}",
                "You are now in Karen mode - act entitled and demand better behavior, like a classic 'Karen' would."
            )
            await update.message.reply_text(f"Excuse me?! 💁‍♀️\n\n{response}")
            
        elif warnings == 2:
            # Second warning - roast them
            user_behavior[user_id]['mode'] = 'roast'
            response = await bot.call_grok(
                f"Roast this rude user '{username}' for being rude twice. Their message: {update.message.text}",
                "You are now in roast mode - give them a clever, funny roast for being rude. Use cannabis and Dudley Bud references."
            )
            await update.message.reply_text(f"🔥 Oh, so we're doing this again? 🔥\n\n{response}")
            
        elif warnings >= 3:
            # Third strike - report
            await update.message.reply_text(
                f"@admins - {username} is being repeatedly disruptive. Please review! 🚨"
            )
        
        return
    
    # Reset to friendly if they're being nice
    if user_behavior[user_id]['mode'] != 'friendly' and not is_rude:
        user_behavior[user_id]['mode'] = 'friendly'
        user_behavior[user_id]['warnings'] = max(0, user_behavior[user_id]['warnings'] - 1)
        await update.message.reply_text(
            "Hey, that's more like it! Thanks for being cool! 😊🌿"
        )
    
    # Check for Dudley Bud questions
    dudley_keywords = ['dudley', 'nft', 'collection', 'mint', 'base', 'blockchain', 'investment']
    is_dudley_question = any(keyword in message_text for keyword in dudley_keywords)
    
    if is_dudley_question:
        # Use project info + Grok
        prompt = f"User asks about Dudley Bud project: {update.message.text}\n\nProject info: {PROJECT_INFO}\n\nAnswer their question helpfully and accurately."
        response = await bot.call_grok(prompt)
        await update.message.reply_text(response)
        return
    
    # Check for cannabis questions
    cannabis_keywords = ['cannabis', 'weed', 'marijuana', 'thc', 'cbd', 'medical', 'strain']
    is_cannabis_question = any(keyword in message_text for keyword in cannabis_keywords)
    
    if is_cannabis_question:
        response = await bot.call_grok(
            f"Answer this cannabis-related question: {update.message.text}",
            "You are knowledgeable about cannabis - provide accurate, educational information."
        )
        await update.message.reply_text(response)
        return
    
    # General chat with Grok
    character = random.choice(DUDLEY_CHARACTERS)
    response = await bot.call_grok(
        f"Respond to this message as the Dudley Bud AI assistant. Sometimes mention one of these characters naturally: {character}. Message: {update.message.text}",
        f"You are the friendly Dudley Bud AI assistant. Current character context: {character}"
    )
    
    # Maybe generate an image
    image_url = await bot.generate_image(f"Cannabis bud character, {update.message.text}")
    
    await update.message.reply_text(response)

async def auto_engagement(context: ContextTypes.DEFAULT_TYPE):
    """Auto post jokes/facts when chat is quiet"""
    global last_activity_time
    
    time_since_activity = time.time() - last_activity_time
    
    # If quiet for 15+ minutes
    if time_since_activity > 900:  # 15 minutes
        chat_id = context.job.chat_id
        
        action = random.choice(['joke', 'fact', 'question'])
        
        if action == 'joke':
            available_jokes = [j for j in JOKES if j not in used_jokes]
            if not available_jokes:
                used_jokes.clear()
                available_jokes = JOKES
            joke = random.choice(available_jokes)
            used_jokes.add(joke)
            await context.bot.send_message(chat_id, f"Chat's a bit quiet... here's a joke! 😄\n\n{joke}")
            
        elif action == 'fact':
            fact = random.choice(MEDICAL_FACTS)
            await context.bot.send_message(chat_id, f"Did you know? 🤔\n\n{fact}")
            
        else:  # question
            questions = [
                "Hey Dudley fam! What's your favorite thing about the project so far? 🌿",
                "Quick question - what features would you love to see next? 🚀",
                "How's everyone doing today? Drop a 🌿 if you're vibing!",
                "Anyone have questions about Dudley Bud? I'm here to help! 😊"
            ]
            await context.bot.send_message(chat_id, random.choice(questions))
        
        last_activity_time = time.time()

def main():
    """Start the bot"""
    if not TELEGRAM_TOKEN:
        print("ERROR: TELEGRAM_BOT_TOKEN not set!")
        return
    
    # Create application
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("about", about_command))
    application.add_handler(CommandHandler("prices", prices_command))
    application.add_handler(CommandHandler("joke", joke_command))
    application.add_handler(CommandHandler("fact", fact_command))
    application.add_handler(CommandHandler("safety", safety_command))
    
    # Message handlers
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(ChatMemberHandler(welcome_new_member, ChatMemberHandler.CHAT_MEMBER))
    
    # Start auto-engagement job (every 20 minutes)
    application.job_queue.run_repeating(
        auto_engagement,
        interval=1200,  # 20 minutes
        first=1200
    )
    
    print("🌿 Dudley Bot is running! 🚀")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()
