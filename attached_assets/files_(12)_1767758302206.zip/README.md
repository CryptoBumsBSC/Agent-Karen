# 🌿 Dudley Bud Guardian Bot

A comprehensive Telegram bot for the Dudley Bud NFT community featuring AI-powered chat, scam detection, auto-engagement, and market tracking.

## 🚀 Features

### Core Features
- ✅ **AI-Powered Chat** - Grok AI integration for intelligent responses
- ✅ **Image Generation** - BananaGun API (20% activation rate)
- ✅ **Smart Greetings** - Welcome new members with safety reminders
- ✅ **Behavior Tracking** - Progressive response system (Friendly → Karen → Roast)
- ✅ **Project Knowledge** - Answers Dudley Bud questions accurately
- ✅ **Cannabis Education** - Medical facts and general information
- ✅ **Scam Detection** - Flags suspicious usernames and behaviors
- ✅ **Auto-Engagement** - Posts jokes/facts when chat is quiet (15+ min)
- ✅ **Market Tracking** - Real-time crypto prices
- ✅ **Character Integration** - Uses Dudley Bud universe characters

### Behavior Modes

**Friendly Mode (Default)**
- Helpful and welcoming
- Answers questions
- Entertains with jokes

**Karen Mode (1st Offense)**
- Entitled and demanding tone
- "Excuse me?!" energy
- Requests better behavior

**Roast Mode (2nd Offense)**
- Clever cannabis-themed roasts
- Funny but firm
- Shows consequences

**Report Mode (3rd Offense)**
- Tags admins
- Documents repeated issues

### Scam Detection

The bot automatically flags:
- 🚫 Crypto addresses in usernames
- 🚫 Marketing terms
- 🚫 Porn-related usernames
- 🚫 Suspicious patterns from documents

## 📋 Setup Instructions

### Step 1: Create Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Send `/newbot`
3. Follow instructions to name your bot
4. Copy the bot token (looks like: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`)
5. Send `/setprivacy` to @BotFather, select your bot, then select "Disable"
6. Send `/setjoingroups` to @BotFather, select your bot, then select "Enable"

### Step 2: Set Up Replit

1. Go to https://replit.com/
2. Click "Create Repl"
3. Choose "Python" as template
4. Name it "dudley-bud-bot"
5. Click "Create Repl"

### Step 3: Upload Files

1. In Replit, delete the default `main.py`
2. Upload all files from this folder:
   - `main.py`
   - `requirements.txt`
   - `.env.example`

### Step 4: Configure Environment Variables

1. In Replit, click the "Secrets" tab (lock icon on left sidebar)
2. Add these secrets:

**Required:**
```
TELEGRAM_BOT_TOKEN = your_bot_token_from_botfather
```

**Optional (for full features):**
```
GROK_API_KEY = your_grok_api_key
BANANAGUN_API_KEY = your_bananagun_key
```

#### Getting Grok API Key (Free):
1. Go to https://console.x.ai/
2. Sign up with your X/Twitter account
3. Navigate to API Keys section
4. Create a new API key
5. Copy and paste into Replit Secrets

#### Getting BananaGun API (Optional):
1. Visit BananaGun website
2. Sign up for API access
3. Get your API key
4. Add to Replit Secrets

### Step 5: Add Bot to Your Group

1. Go to your Telegram group: https://t.me/dudley420
2. Click group name → "Add Members"
3. Search for your bot name
4. Add the bot
5. **Make bot an Admin** with these permissions:
   - Delete messages
   - Ban users
   - Pin messages
   - Add users

### Step 6: Run the Bot

1. In Replit, click the green "Run" button
2. You should see: "🌿 Dudley Bot is running! 🚀"
3. Test in your Telegram group by typing `/start`

## 🎮 Commands

| Command | Description |
|---------|-------------|
| `/start` | Show welcome message and command list |
| `/about` | Display Dudley Bud project information |
| `/prices` | Check current crypto prices (ETH, BASE) |
| `/joke` | Get a random cannabis/dad joke |
| `/fact` | Learn a medical cannabis fact |
| `/safety` | View security and scam prevention tips |

## 🤖 Bot Behavior

### Automatic Actions

**New Member Joins:**
- Scans username for red flags
- Welcomes them warmly
- Reminds about pinned messages
- Warns about DMs and links

**Chat Activity:**
- Responds to questions about Dudley Bud
- Answers cannabis questions via Grok
- Tracks user behavior for warnings
- Never roasts admins (unless they ask!)

**Quiet Chat (15+ minutes):**
- Posts a joke
- Shares a medical fact
- Asks the community a question

**Rude Behavior:**
1. First time → Karen mode response
2. Second time → Roast mode
3. Third time → Report to admins

### What Bot Protects Against

Based on your scam detection documents:

✅ Crypto addresses in usernames
✅ Marketing spam accounts
✅ Porn-related usernames
✅ Phishing link patterns
✅ Blackmail/sextortion language
✅ Investment scam terms
✅ Fake airdrop accounts

## 🛠️ Troubleshooting

### Bot Not Responding
- Check if bot is admin in the group
- Verify TELEGRAM_BOT_TOKEN in Secrets
- Check Replit console for errors

### Grok Not Working
- Verify GROK_API_KEY is correct
- Check X.AI API quota/limits
- Bot will still work with fallback responses

### Images Not Generating
- This feature is optional (20% activation)
- Requires BANANAGUN_API_KEY
- Bot works fine without it

### Bot Stops After Time
- Replit free tier may stop after inactivity
- Upgrade to "Always On" in Replit
- Or use a keep-alive service

## 📊 Monitoring

Watch Replit console for:
- `🌿 Dudley Bot is running! 🚀` - Successfully started
- API errors - Check keys if you see these
- User warnings - Track community behavior

## 🎯 Customization

### Add More Jokes
Edit the `JOKES` list in `main.py`:
```python
JOKES = [
    "Your new joke here! 🌿",
    # ... more jokes
]
```

### Add More Characters
Edit `DUDLEY_CHARACTERS` list:
```python
DUDLEY_CHARACTERS = [
    "New Character - Description",
]
```

### Adjust Timing
Change auto-engagement interval (default 15 min):
```python
if time_since_activity > 900:  # 900 seconds = 15 minutes
```

### Change Image Generation Rate
Adjust from 20% to your preference:
```python
if random.random() > 0.2:  # 0.2 = 20% chance
```

## ⚠️ Important Notes

1. **Admin Protection**: Bot won't roast admins unless they specifically ask
2. **Scam Detection**: Bot warns but doesn't auto-ban (admins decide)
3. **No DMs**: Bot only works in groups, not private messages
4. **Rate Limits**: Free API tiers have limits - monitor usage
5. **Project Info**: Keep PROJECT_INFO updated with latest details

## 🔒 Security Best Practices

- Never share your bot token publicly
- Keep API keys in Replit Secrets, not code
- Regularly update dependencies
- Monitor bot logs for suspicious activity
- Make sure privacy mode is disabled for group detection

## 📞 Support

If you need help:
1. Check Replit console for error messages
2. Verify all API keys are correct
3. Ensure bot has admin permissions
4. Test commands one by one

## 🌿 Final Tips

- Start with just TELEGRAM_BOT_TOKEN to test basic features
- Add Grok API key later for AI responses
- Image generation is completely optional
- Bot learns from chat patterns over time
- Customize jokes and facts for your community

**Ready to protect the Dudley Bud community! 🚀🌿**
