# 🚀 Quick Start Guide - Replit Deployment

## Fast Track Setup (5 Minutes)

### 1. Create Your Bot
1. Open Telegram
2. Search `@BotFather`
3. Send: `/newbot`
4. Name it: `Dudley Guardian Bot`
5. Username: `dudley_guardian_bot` (or similar)
6. **Copy the token** (looks like: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### 2. Setup Replit
1. Go to: https://replit.com/
2. Sign in / Create account
3. Click: **"+ Create Repl"**
4. Select: **"Import from GitHub"** OR **"Python"**
5. Name: `dudley-bot`

### 3. Upload Files
Drag and drop these files into Replit:
- `main.py`
- `requirements.txt`
- `README.md`

### 4. Add Bot Token
1. Click **"Secrets"** (🔒 icon) in left sidebar
2. Click **"+ New Secret"**
3. Key: `TELEGRAM_BOT_TOKEN`
4. Value: Paste your token from step 1
5. Click **"Add Secret"**

### 5. Run Bot
1. Click big green **"Run"** button
2. Wait for: `🌿 Dudley Bot is running! 🚀`

### 6. Add to Your Group
1. Open: https://t.me/dudley420
2. Click group name → "Administrators" → "Add Administrator"
3. Search your bot name
4. Enable permissions:
   - ✅ Delete messages
   - ✅ Ban users
   - ✅ Pin messages
5. Save

### 7. Test It!
In your Telegram group, type:
```
/start
```

You should get a welcome message! 🎉

---

## Optional: Add Grok AI (For Smart Responses)

### Getting Free Grok API
1. Go to: https://console.x.ai/
2. Sign in with X/Twitter
3. Click: "API Keys" → "Create API Key"
4. Copy the key
5. In Replit Secrets, add:
   - Key: `GROK_API_KEY`
   - Value: Your Grok API key

### What This Adds:
- Smart AI responses to questions
- Cannabis knowledge answers
- Roast mode for rude users
- Karen mode responses

---

## Keeping Bot Running 24/7

### Free Method (Ping Service):
1. Copy your Replit URL (looks like: `https://dudley-bot.username.repl.co`)
2. Go to: https://uptimerobot.com/
3. Sign up free
4. Add monitor → HTTP(s)
5. Paste your Replit URL
6. Set interval: 5 minutes

### Paid Method:
Upgrade Replit to "Hacker" plan for "Always On" feature

---

## Troubleshooting

### Bot Not Responding?
**Check:**
- [ ] Is bot admin in group?
- [ ] Did you add TELEGRAM_BOT_TOKEN to Secrets?
- [ ] Is Replit still running? (Check console)

**Fix:**
1. Click "Stop" in Replit
2. Click "Run" again
3. Test with `/start`

### "Update is too old" Error?
This is normal when restarting. Just ignore it.

### Can't Add Bot to Group?
1. Go back to @BotFather
2. Send: `/setjoingroups`
3. Select your bot
4. Choose: "Enable"
5. Try adding again

### No AI Responses?
Bot works without GROK_API_KEY, it just won't have advanced AI features. Add the key to enable smart chat.

---

## Testing Checklist

Test each feature:

- [ ] `/start` - Shows welcome
- [ ] `/about` - Shows project info
- [ ] `/joke` - Tells a joke
- [ ] `/fact` - Shares cannabis fact
- [ ] `/prices` - Shows crypto prices
- [ ] `/safety` - Shows security tips
- [ ] New member joins - Gets welcome message
- [ ] Ask about Dudley Bud - Gets answer
- [ ] Be rude - Gets Karen mode response
- [ ] Quiet for 15+ min - Bot posts joke/fact

---

## Next Steps

Once running:
1. Monitor for first few hours
2. Watch how it greets new members
3. Test the warning system (carefully!)
4. Add more jokes/facts if you want
5. Share with team that bot is live

**You're all set! 🌿🚀**

Need help? Check the full README.md for detailed instructions.
